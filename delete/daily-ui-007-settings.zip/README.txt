A Pen created at CodePen.io. You can find this one at https://codepen.io/juliepark/pen/pLMxoP.

 Hulu settings redesign. Toggle between the tabs on the left hand bar!